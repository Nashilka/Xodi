# To Do

### Features

- comics by first letter
- update check_tool
- remove plot references as Picture ListItem doesn't have it ?
- download chapter as zip ?
- blogspot quality settings ?

### Default GUI

- ...

### Custom GUI

- add rotate buttons to portrait mode ?
- setting for sectors number ?
- crrt page loading bar at portrait mode ?
- use arrow keys to navigate image instead controls click ?

- zoom and rotate animations to image control ? it won't work
- unstretch button ? nope, as it would be same as scale down

### Image Processing

- split comic panels ?
	- https://maxhalford.github.io/blog/comic-book-panel-segmentation
	- https://github.com/kanjieater/ComicEater
	- https://github.com/Ajira-FR/comics-splitter
	- https://github.com/slee500/cs543-sp19

### Providers

- https://everythingmoe.com/
